from flask import Flask, request
app = Flask(__name__)

@app.route("/")

def home():
    return "Welcome to student registration portal!"

@app.route("/courses", methods=["GET"])
def courses():
    return "Available Courses: Computer Science, Mathematics, Physics"

@app.route("/final-page", methods=["GET"])
def final_page():
    return """
    <h2>Registration Portal</h2>
    <form action="/register" method="POST">
        <input type="text" name="name" placeholder="Enter your name"> 
        <input type="email" name="email" placeholder="Enter your email"> 
        <select name="course">
            <option value="Computer Science">Computer Science</option>
            <option value="Mathematics">Mathematics</option>
            <option value="Physics">Physics</option>
        </select>
        <button type="submit">Register</button>
    </form>
    """

@app.route("/register", methods=["POST"]) 
def register():
    name = request.form.get("name")
    email = request.form.get("email")
    course = request.form.get("course")
    return f"Thank you, {name}! You have been registered for {course}."

if __name__ == "__main__":
    app.run(debug=True)