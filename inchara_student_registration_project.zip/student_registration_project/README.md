# Student Registration System

## Description
- A simple web application built using Python and Flask
to register students.

## Features
- Student name input
- Email input
- Course input
- Registration result page
- Required-field validation

## Requirements
- Python
- Flask

## How to Run
1. Open the project folder in VS Code.
2. Open the terminal.
3. Install dependencies using:
   python -m pip install -r requirements.txt
4. Run the application using:
   python app.py
5. Open http://127.0.0.1:5000 in your browser.